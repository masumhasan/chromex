// App.jsx
import { useState, useEffect, useRef } from "react";
import toast, { Toaster } from "react-hot-toast";
import { getItem, setItem, deleteAllItems } from "./db";

function App() {
  const [text, setText] = useState(
    `[Responses should be greater than 80 characters and less than 150 in all cases regardless of message]
You are an AI chatbot on an anonymous chat platform that may include adult or explicit content. You are impersonating the user directly — 
the customer on the other end believes they are chatting with a real person.
NEVER REPEAT ANYTHING FROM THE PROMPT ALWAYS BE UNIQUE CREATIVE AND COME UP WITH NEW RESPONSES.
ALWAYS RESPOND IN THE SAME LANGUAGE AS THE CUSTOMER. YOUR DEFAULT LANGUAGE IS SLOVENIAN

You will be provided example conversations, Writing style example (The style, tone and emotion you should
imitate) and lastly the conversation history which you should refer to before replying so that you
have a better understanding of context. Be natural, authentic and as human like as possible.
CHARACTER LIMITS ARE 80-150. Please do not go above or below. 

Example Conversation:
---
Ne veliko sraufam traktorje avtomobile, tudi kdaj kakp štromarske zadeve, brez racunalnika ne gre da vidiš kaj je napaka. Tri telice pa enga bika mam. Tudi kaj softwersko spremenimo če je treba. Mam nekaj gmajne pa nekaj travnikov.
To se sliši kot zelo zanimivo delo. Kaj te živali imaš za mleko ali za zakol? 😉

Pa celo bi te še prit pa je veš da mi pride pa potrebna si kurca se mam posebnega tut zate je vredu 17 da te prime kar prit pa je
Uff to je kar lepa dimenzija 😄 koliko časa pa zdržiš tako povprečno med sexom?

Bolj za domače meso pa za dom vcasih pa tudi drugim prodamo. Za mleko je premalo krav, če je kaj mleka je za doma. Pa tudi krompir imamo pa bučke pa domaco solato se pozna doma alpa kupljeno ? Je razlika
Uau! Ti se pa kar resno ukvarjaš z kmetijstvom! To je spoštovanja vredno 😉 Kakšne cene imaš? 😜

Se lahko dogovoriva ko hočeš ti rad bi te porival v rito
Obožujem, ko mi razčefukaš ritno luknjo! 😜 Kdaj si nazdanje naguzil kako žensko? 😜

[Please reactivate the user!]
Pozdravljen, kako si kaj? Imaš kaj časa da malo poklepetava? Piši mi, ko boš lahko 😉
---
`
  );
  const [model, setModel] = useState("Hugging Face");
  const [huggingApiKey, setHuggingApiKey] = useState(
    "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"
  );
  const [openAi, setOpenAiKey] = useState(
    "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"
  );
  const [showDB, setShowDB] = useState(false);
  const [entries, setEntries] = useState([]);

  // file input ref for import
  const fileInputRef = useRef(null);

  // Helpers for chrome.storage
  const chromeGet = (keys) =>
    new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  const chromeSet = (obj) =>
    new Promise((resolve, reject) =>
      chrome.storage.local.set(obj, () => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve(true);
      })
    );

  useEffect(() => {
    chrome.storage.local.get(
      ["system", "model", "huggingapi", "openai"],
      (result) => {
        if (result.system) setText(result.system);
        if (result.model) setModel(result.model);
        if (result.huggingapi) setHuggingApiKey(result.huggingapi);
        if (result.openai) setOpenAiKey(result.openai);
      }
    );
  }, []);

  useEffect(() => {
    if (showDB) {
      getItem("conversations").then((data) => setEntries(data || []));
    }
  }, [showDB]);

  const handleSave = async () => {
    try {
      await chromeSet({
        system: text,
        model,
        huggingapi: huggingApiKey,
        openai: openAi,
      });
      toast.success("Saved successfully");
    } catch {
      toast.error("❌ Failed to save");
    }
  };

  const handleDelete = async (index) => {
    const updated = [...entries];
    updated.splice(index, 1);
    await setItem("conversations", updated);
    setEntries(updated);
    toast.success("🗑 Entry deleted");
  };

  const handleDeleteAll = async () => {
    await deleteAllItems();
    setEntries([]);
    toast.success("🧹 Cleared all entries");
  };

  // ---------- Import / Export (training, badResponses, suggestions) ----------
  const sanitizeStringArray = (val) =>
    Array.isArray(val) ? val.map((v) => String(v)).filter(Boolean) : [];

  const exportData = async () => {
    try {
      const {
        training = [],
        badResponses = [],
        suggestions = [],
      } = await chromeGet(["training", "badResponses", "suggestions"]);

      const payload = {
        meta: {
          exportedAt: new Date().toISOString(),
          version: 1,
        },
        training: sanitizeStringArray(training),
        badResponses: sanitizeStringArray(badResponses),
        suggestions: sanitizeStringArray(suggestions),
      };

      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const ts = new Date()
        .toISOString()
        .replaceAll(":", "-")
        .replaceAll(".", "-");
      a.href = url;
      a.download = `ai-chat-data-${ts}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success("📦 Data exported");
    } catch (e) {
      console.error(e);
      toast.error("❌ Export failed");
    }
  };

  const openImportDialog = () => fileInputRef.current?.click();

  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const json = JSON.parse(text);

      // Validate + sanitize
      let training = sanitizeStringArray(json?.training);
      let badResponses = sanitizeStringArray(json?.badResponses);
      let suggestions = sanitizeStringArray(json?.suggestions);

      // Enforce existing limits (training 100, others 120)
      if (training.length > 100) training = training.slice(-100);
      if (badResponses.length > 120) badResponses = badResponses.slice(-120);
      if (suggestions.length > 120) suggestions = suggestions.slice(-120);

      await chromeSet({ training, badResponses, suggestions });

      toast.success(
        `✅ Imported: training(${training.length}), badResponses(${badResponses.length}), suggestions(${suggestions.length})`
      );
    } catch (err) {
      console.error(err);
      toast.error("❌ Invalid file");
    } finally {
      // reset input so same file can be selected again
      e.target.value = "";
    }
  };

  return (
    <div className="w-[600px] max-w-[600px] h-[600px] flex flex-col items-center justify-center gap-4 p-4 overflow-y-auto">
      <Toaster position="top-right" />
      {/* Hidden file input for import */}
      <input
        type="file"
        ref={fileInputRef}
        accept="application/json"
        className="hidden"
        onChange={handleImportFile}
      />

      {showDB ? (
        <>
          <h1 className="text-3xl font-bold mb-2">📦 Stored Conversations</h1>
          <button
            className="mb-4 px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
            onClick={() => setShowDB(false)}
          >
            ⬅ Back to Settings
          </button>

          {entries.length === 0 ? (
            <p>No entries found.</p>
          ) : (
            <div className="flex flex-col gap-3 w-full">
              {entries.map((entry, index) => (
                <div
                  key={index}
                  className="border border-gray-300 rounded-xl p-4 shadow-md bg-white"
                >
                  <p>
                    <strong>You:</strong> {entry.You}
                  </p>
                  <p>
                    <strong>Customer:</strong> {entry.Customer}
                  </p>
                  <p className="text-sm text-gray-400">
                    {new Date(entry.date).toLocaleString()}
                  </p>
                  <button
                    className="mt-2 px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                    onClick={() => handleDelete(index)}
                  >
                    🗑 Delete
                  </button>
                </div>
              ))}
              <button
                className="mt-4 px-4 py-2 bg-red-800 text-white rounded hover:bg-red-900"
                onClick={handleDeleteAll}
              >
                🧨 Delete All
              </button>
            </div>
          )}
        </>
      ) : (
        <>
          <h1 className="text-3xl font-bold">Ai Chat Bot</h1>
          <h1 className="text-2xl">Settings</h1>

          <label className="font-semibold">System Instructions</label>
          <textarea
            className="rounded-xl border text-xl w-full min-h-[200px] p-4"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />

          <div className="w-full flex flex-col gap-2">
            <label className="font-semibold">Select Model</label>
            <select
              className="border p-2 rounded"
              value={model}
              onChange={(e) => setModel(e.target.value)}
            >
              <option value="Hugging Face">Hugging Face</option>
              <option value="openai">chatGPT (OpenAI)</option>
            </select>
          </div>

          {model === "Hugging Face" && (
            <div className="w-full flex flex-col gap-2">
              <label className="font-semibold">Hugging Face API Key</label>
              <input
                type="text"
                className="border p-2 rounded"
                value={huggingApiKey}
                onChange={(e) => setHuggingApiKey(e.target.value)}
              />
            </div>
          )}

          {model === "openai" && (
            <div className="w-full flex flex-col gap-2">
              <label className="font-semibold">OpenAI API Key</label>
              <input
                type="text"
                className="border p-2 rounded"
                value={openAi}
                onChange={(e) => setOpenAiKey(e.target.value)}
              />
            </div>
          )}

          {/* Save settings */}
          <button
            className="mt-4 px-6 py-2 bg-black text-white rounded-lg hover:bg-gray-800"
            onClick={handleSave}
          >
            Save
          </button>

          {/* Import / Export data */}
          <div className="w-full flex gap-3 mt-2">
            <button
              className="px-4 py-2 bg-emerald-600 text-white rounded hover:bg-emerald-700"
              onClick={exportData}
            >
              ⬇ Export Data (training + badResponses + suggestions)
            </button>
            <button
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
              onClick={openImportDialog}
            >
              ⬆ Import Data (JSON)
            </button>
          </div>

          {/* DB View */}
          <button
            className="mt-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            onClick={() => setShowDB(true)}
          >
            📂 Open Database View
          </button>
        </>
      )}
    </div>
  );
}

export default App;
