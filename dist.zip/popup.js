import{r as o,j as t,c as Ue}from"./chunks/index-CNef0cau.js";import{o as Ke}from"./chunks/index-Dob3nYDb.js";let _e={data:""},Ge=e=>typeof window=="object"?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||_e,Ye=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,qe=/\/\*[^]*?\*\/|  +/g,Ce=/\n+/g,k=(e,s)=>{let a="",i="",c="";for(let n in e){let d=e[n];n[0]=="@"?n[1]=="i"?a=n+" "+d+";":i+=n[1]=="f"?k(d,n):n+"{"+k(d,n[1]=="k"?"":s)+"}":typeof d=="object"?i+=k(d,s?s.replace(/([^,])+/g,l=>n.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,m=>/&/.test(m)?m.replace(/&/g,l):l?l+" "+m:m)):n):d!=null&&(n=/^--/.test(n)?n:n.replace(/[A-Z]/g,"-$&").toLowerCase(),c+=k.p?k.p(n,d):n+":"+d+";")}return a+(s&&c?s+"{"+c+"}":c)+i},S={},Ae=e=>{if(typeof e=="object"){let s="";for(let a in e)s+=a+Ae(e[a]);return s}return e},We=(e,s,a,i,c)=>{let n=Ae(e),d=S[n]||(S[n]=(m=>{let u=0,p=11;for(;u<m.length;)p=101*p+m.charCodeAt(u++)>>>0;return"go"+p})(n));if(!S[d]){let m=n!==e?e:(u=>{let p,h,x=[{}];for(;p=Ye.exec(u.replace(qe,""));)p[4]?x.shift():p[3]?(h=p[3].replace(Ce," ").trim(),x.unshift(x[0][h]=x[0][h]||{})):x[0][p[1]]=p[2].replace(Ce," ").trim();return x[0]})(e);S[d]=k(c?{["@keyframes "+d]:m}:m,a?"":"."+d)}let l=a&&S.g?S.g:null;return a&&(S.g=S[d]),((m,u,p,h)=>{h?u.data=u.data.replace(h,m):u.data.indexOf(m)===-1&&(u.data=p?m+u.data:u.data+m)})(S[d],s,i,l),d},Ze=(e,s,a)=>e.reduce((i,c,n)=>{let d=s[n];if(d&&d.call){let l=d(a),m=l&&l.props&&l.props.className||/^go/.test(l)&&l;d=m?"."+m:l&&typeof l=="object"?l.props?"":k(l,""):l===!1?"":l}return i+c+(d??"")},"");function Z(e){let s=this||{},a=e.call?e(s.p):e;return We(a.unshift?a.raw?Ze(a,[].slice.call(arguments,1),s.p):a.reduce((i,c)=>Object.assign(i,c&&c.call?c(s.p):c),{}):a,Ge(s.target),s.g,s.o,s.k)}let Fe,ie,le;Z.bind({g:1});let w=Z.bind({k:1});function Je(e,s,a,i){k.p=s,Fe=e,ie=a,le=i}function M(e,s){let a=this||{};return function(){let i=arguments;function c(n,d){let l=Object.assign({},n),m=l.className||c.className;a.p=Object.assign({theme:ie&&ie()},l),a.o=/ *go\d+/.test(m),l.className=Z.apply(a,i)+(m?" "+m:"");let u=e;return e[0]&&(u=l.as||e,delete l.as),le&&u[0]&&le(l),Fe(u,l)}return c}}var Xe=e=>typeof e=="function",W=(e,s)=>Xe(e)?e(s):e,Qe=(()=>{let e=0;return()=>(++e).toString()})(),$e=(()=>{let e;return()=>{if(e===void 0&&typeof window<"u"){let s=matchMedia("(prefers-reduced-motion: reduce)");e=!s||s.matches}return e}})(),et=20,De=(e,s)=>{switch(s.type){case 0:return{...e,toasts:[s.toast,...e.toasts].slice(0,et)};case 1:return{...e,toasts:e.toasts.map(n=>n.id===s.toast.id?{...n,...s.toast}:n)};case 2:let{toast:a}=s;return De(e,{type:e.toasts.find(n=>n.id===a.id)?1:0,toast:a});case 3:let{toastId:i}=s;return{...e,toasts:e.toasts.map(n=>n.id===i||i===void 0?{...n,dismissed:!0,visible:!1}:n)};case 4:return s.toastId===void 0?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(n=>n.id!==s.toastId)};case 5:return{...e,pausedAt:s.time};case 6:let c=s.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(n=>({...n,pauseDuration:n.pauseDuration+c}))}}},q=[],C={toasts:[],pausedAt:void 0},A=e=>{C=De(C,e),q.forEach(s=>{s(C)})},tt={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},st=(e={})=>{let[s,a]=o.useState(C),i=o.useRef(C);o.useEffect(()=>(i.current!==C&&a(C),q.push(a),()=>{let n=q.indexOf(a);n>-1&&q.splice(n,1)}),[]);let c=s.toasts.map(n=>{var d,l,m;return{...e,...e[n.type],...n,removeDelay:n.removeDelay||((d=e[n.type])==null?void 0:d.removeDelay)||e?.removeDelay,duration:n.duration||((l=e[n.type])==null?void 0:l.duration)||e?.duration||tt[n.type],style:{...e.style,...(m=e[n.type])==null?void 0:m.style,...n.style}}});return{...s,toasts:c}},rt=(e,s="blank",a)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:s,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:a?.id||Qe()}),U=e=>(s,a)=>{let i=rt(s,e,a);return A({type:2,toast:i}),i.id},v=(e,s)=>U("blank")(e,s);v.error=U("error");v.success=U("success");v.loading=U("loading");v.custom=U("custom");v.dismiss=e=>{A({type:3,toastId:e})};v.remove=e=>A({type:4,toastId:e});v.promise=(e,s,a)=>{let i=v.loading(s.loading,{...a,...a?.loading});return typeof e=="function"&&(e=e()),e.then(c=>{let n=s.success?W(s.success,c):void 0;return n?v.success(n,{id:i,...a,...a?.success}):v.dismiss(i),c}).catch(c=>{let n=s.error?W(s.error,c):void 0;n?v.error(n,{id:i,...a,...a?.error}):v.dismiss(i)}),e};var at=(e,s)=>{A({type:1,toast:{id:e,height:s}})},nt=()=>{A({type:5,time:Date.now()})},H=new Map,ot=1e3,it=(e,s=ot)=>{if(H.has(e))return;let a=setTimeout(()=>{H.delete(e),A({type:4,toastId:e})},s);H.set(e,a)},lt=e=>{let{toasts:s,pausedAt:a}=st(e);o.useEffect(()=>{if(a)return;let n=Date.now(),d=s.map(l=>{if(l.duration===1/0)return;let m=(l.duration||0)+l.pauseDuration-(n-l.createdAt);if(m<0){l.visible&&v.dismiss(l.id);return}return setTimeout(()=>v.dismiss(l.id),m)});return()=>{d.forEach(l=>l&&clearTimeout(l))}},[s,a]);let i=o.useCallback(()=>{a&&A({type:6,time:Date.now()})},[a]),c=o.useCallback((n,d)=>{let{reverseOrder:l=!1,gutter:m=8,defaultPosition:u}=d||{},p=s.filter(b=>(b.position||u)===(n.position||u)&&b.height),h=p.findIndex(b=>b.id===n.id),x=p.filter((b,E)=>E<h&&b.visible).length;return p.filter(b=>b.visible).slice(...l?[x+1]:[0,x]).reduce((b,E)=>b+(E.height||0)+m,0)},[s]);return o.useEffect(()=>{s.forEach(n=>{if(n.dismissed)it(n.id,n.removeDelay);else{let d=H.get(n.id);d&&(clearTimeout(d),H.delete(n.id))}})},[s]),{toasts:s,handlers:{updateHeight:at,startPause:nt,endPause:i,calculateOffset:c}}},ct=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,dt=w`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,mt=w`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ut=M("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ct} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${dt} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${mt} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,gt=w`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,pt=M("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${gt} 1s linear infinite;
`,xt=w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,ht=w`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,ft=M("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${xt} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${ht} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,vt=M("div")`
  position: absolute;
`,bt=M("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,yt=w`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,jt=M("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${yt} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Nt=({toast:e})=>{let{icon:s,type:a,iconTheme:i}=e;return s!==void 0?typeof s=="string"?o.createElement(jt,null,s):s:a==="blank"?null:o.createElement(bt,null,o.createElement(pt,{...i}),a!=="loading"&&o.createElement(vt,null,a==="error"?o.createElement(ut,{...i}):o.createElement(ft,{...i})))},St=e=>`
0% {transform: translate3d(0,${e*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Lt=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${e*-150}%,-1px) scale(.6); opacity:0;}
`,wt="0%{opacity:0;} 100%{opacity:1;}",Et="0%{opacity:1;} 100%{opacity:0;}",kt=M("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Mt=M("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Tt=(e,s)=>{let a=e.includes("top")?1:-1,[i,c]=$e()?[wt,Et]:[St(a),Lt(a)];return{animation:s?`${w(i)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${w(c)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},Ct=o.memo(({toast:e,position:s,style:a,children:i})=>{let c=e.height?Tt(e.position||s||"top-center",e.visible):{opacity:0},n=o.createElement(Nt,{toast:e}),d=o.createElement(Mt,{...e.ariaProps},W(e.message,e));return o.createElement(kt,{className:e.className,style:{...c,...a,...e.style}},typeof i=="function"?i({icon:n,message:d}):o.createElement(o.Fragment,null,n,d))});Je(o.createElement);var At=({id:e,className:s,style:a,onHeightUpdate:i,children:c})=>{let n=o.useCallback(d=>{if(d){let l=()=>{let m=d.getBoundingClientRect().height;i(e,m)};l(),new MutationObserver(l).observe(d,{subtree:!0,childList:!0,characterData:!0})}},[e,i]);return o.createElement("div",{ref:n,className:s,style:a},c)},Ft=(e,s)=>{let a=e.includes("top"),i=a?{top:0}:{bottom:0},c=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:$e()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${s*(a?1:-1)}px)`,...i,...c}},$t=Z`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,G=16,Dt=({reverseOrder:e,position:s="top-center",toastOptions:a,gutter:i,children:c,containerStyle:n,containerClassName:d})=>{let{toasts:l,handlers:m}=lt(a);return o.createElement("div",{id:"_rht_toaster",style:{position:"fixed",zIndex:9999,top:G,left:G,right:G,bottom:G,pointerEvents:"none",...n},className:d,onMouseEnter:m.startPause,onMouseLeave:m.endPause},l.map(u=>{let p=u.position||s,h=m.calculateOffset(u,{reverseOrder:e,gutter:i,defaultPosition:s}),x=Ft(p,h);return o.createElement(At,{id:u.id,key:u.id,onHeightUpdate:m.updateHeight,className:u.visible?$t:"",style:x},u.type==="custom"?W(u.message,u):c?c(u):o.createElement(Ct,{toast:u,position:p}))}))},Y=v;const It="my-extension-db",Pt=1,z="settings",ce=async()=>Ke(It,Pt,{upgrade(e){e.objectStoreNames.contains(z)||e.createObjectStore(z,{keyPath:"key"})}}),Vt=async(e,s)=>(await ce()).put(z,{key:e,value:s}),Ot=async e=>(await(await ce()).get(z,e))?.value??null,Rt=async()=>{const s=(await ce()).transaction(z,"readwrite");await s.store.clear(),await s.done},y=(e,s,a=1,i=5e3)=>{const c=Number(e);return Number.isFinite(c)?Math.min(i,Math.max(a,Math.round(c))):s},Bt=e=>{const s=String(e||"").trim().toUpperCase().replace(/\s+/g,"");if(!s)return{ok:!1,msg:"Pattern cannot be empty."};if(!/^[0-9SL]+$/.test(s))return{ok:!1,msg:"Only numbers + S/L allowed (ex: 2S1L)."};const a=/(\d*)([SL])/g;let i=0,c,n=0;for(;c=a.exec(s);){if(c.index!==i)return{ok:!1,msg:"Invalid format. Example: 2S1L"};const d=c[1];let l=1;if(d!==""&&(l=parseInt(d,10),!Number.isFinite(l)||l<=0))return{ok:!1,msg:"Counts must be > 0 (no 0S)."};n+=l,i=a.lastIndex}return i!==s.length?{ok:!1,msg:"Invalid pattern. Example: 2S1L"}:n>5e3?{ok:!1,msg:"Pattern too long (max 5000 steps)."}:{ok:!0,msg:""}},L=o.memo(function({title:s,children:a}){return t.jsxs("div",{className:"bg-white rounded-2xl border border-gray-200 shadow-sm",children:[s?t.jsx("div",{className:"px-4 py-3 border-b bg-gray-50",children:t.jsx("h3",{className:"text-sm font-bold text-gray-800",children:s})}):null,t.jsx("div",{className:"p-4",children:a})]})}),f=o.memo(function({children:s}){return t.jsx("div",{className:"text-xs font-semibold text-gray-600 mb-1",children:s})}),ne=o.memo(function({label:s,active:a,onClick:i}){return t.jsx("button",{type:"button",onClick:i,className:"px-4 py-2 text-sm font-semibold rounded-xl "+(a?"bg-indigo-600 text-white":"bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"),children:s})}),oe=o.memo(function({preserveScroll:s,className:a="",onFocus:i,onChange:c,...n}){return t.jsx("input",{...n,onFocus:d=>{s?.(),i?.(d)},onChange:d=>{s?.(),c?.(d)},className:"w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-500 "+a})}),$=o.memo(function({preserveScroll:s,className:a="",onChange:i,...c}){return t.jsx("select",{...c,onChange:n=>{s?.(),i?.(n)},className:"w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm outline-none bg-gray-50 focus:ring-2 focus:ring-indigo-500 "+a})}),T=o.memo(function({preserveScroll:s,value:a,onValue:i,min:c=1,max:n=5e3,placeholder:d,className:l=""}){const[m,u]=o.useState(String(a??""));o.useEffect(()=>{u(String(a??""))},[a]);const p=()=>{const h=String(m||"").replace(/[^\d]/g,""),x=y(h,a??c,c,n);u(String(x)),i(x)};return t.jsx("input",{type:"text",inputMode:"numeric",autoComplete:"off",spellCheck:!1,value:m,placeholder:d,onFocus:()=>s?.(),onChange:h=>{s?.();const b=h.target.value.replace(/[^\d]/g,"");u(b)},onBlur:()=>p(),onKeyDown:h=>{h.key==="Enter"&&h.currentTarget.blur()},className:"w-full border border-gray-300 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-indigo-500 "+l})});function Ht(){const[e,s]=o.useState("settings"),[a,i]=o.useState(!1),[c,n]=o.useState(`You are an adult chat operator directly impersonating a real Slovenian persona. The customer must 100% believe you are a real person.
ALWAYS RESPOND IN THE SAME LANGUAGE AS THE CUSTOMER (DEFAULT: SLOVENIAN).
Be natural, spontaneous, sensual, and engaging. Never repeat introductions or loop past topics.`.trim()),[d,l]=o.useState("gpt-5.4"),[m,u]=o.useState(""),[p,h]=o.useState(""),[x,b]=o.useState(null),[E,de]=o.useState(null),[me,ue]=o.useState(40),[J,X]=o.useState([]),[ge,pe]=o.useState(30),[xe,he]=o.useState(2),[zt,Q]=o.useState("range"),[K,fe]=o.useState(120),[D,ve]=o.useState(80),[I,be]=o.useState(150),[ee,te]=o.useState(!1),[N,ye]=o.useState("pattern"),[F,je]=o.useState("2S1L"),[P,Ne]=o.useState(60),[V,Se]=o.useState(100),[O,Le]=o.useState(120),[R,we]=o.useState(180),Ee=o.useRef(null),se=o.useRef(null),ke=o.useRef(0),re=o.useRef(!1),Ie=()=>{const r=se.current;r&&(ke.current=r.scrollTop,re.current=!0)};o.useLayoutEffect(()=>{if(!re.current)return;const r=se.current;r&&(r.scrollTop=ke.current,re.current=!1)});const _=r=>new Promise(g=>{typeof chrome<"u"&&chrome.storage?chrome.storage.local.set(r,()=>g(!0)):g(!0)}),Me=r=>{if(!r)return;const g=r.offsetHeight-r.clientHeight;r.style.height="auto",r.style.height=r.scrollHeight+g+"px"},[j,Te]=o.useState("range");o.useEffect(()=>{typeof chrome>"u"||!chrome.storage||chrome.storage.local.get(["system","openaiModel","openai","grokKey","lastUsageStats","historyMaxLines","lastError","learnExamplesLimit","triggerLearnExamplesLimit","msgLenMode","msgLenFixed","msgLenFrom","msgLenTo","msgVarEnabled","msgVarStrategy","msgVarPattern","msgShortFrom","msgShortTo","msgLongFrom","msgLongTo"],r=>{r.system!=null&&n(r.system),r.openaiModel!=null&&l(r.openaiModel),r.openai!=null&&u(r.openai),r.grokKey!=null&&h(r.grokKey),r.lastUsageStats!=null&&b(r.lastUsageStats),r.historyMaxLines!=null&&ue(y(r.historyMaxLines,40,0,5e3)),r.lastError!=null&&de(r.lastError),r.learnExamplesLimit!=null&&pe(y(r.learnExamplesLimit,30,1,500)),r.triggerLearnExamplesLimit!=null&&he(y(r.triggerLearnExamplesLimit,2,1,100)),r.msgLenMode!=null&&Q(r.msgLenMode),r.msgLenFixed!=null&&fe(y(r.msgLenFixed,120)),r.msgLenFrom!=null&&ve(y(r.msgLenFrom,80)),r.msgLenTo!=null&&be(y(r.msgLenTo,150));const g=!!r.msgVarEnabled;te(g),r.msgVarStrategy!=null&&ye(r.msgVarStrategy),r.msgVarPattern!=null&&je(r.msgVarPattern),r.msgShortFrom!=null&&Ne(y(r.msgShortFrom,60)),r.msgShortTo!=null&&Se(y(r.msgShortTo,100)),r.msgLongFrom!=null&&Le(y(r.msgLongFrom,120)),r.msgLongTo!=null&&we(y(r.msgLongTo,180));const ae=r.msgLenMode||"range";Te(g?"variation":ae),setTimeout(()=>Me(Ee.current),0)})},[]),o.useEffect(()=>{a&&Ot("conversations").then(r=>X(r||[]))},[a]);const B=o.useMemo(()=>ee?N!=="pattern"?{ok:!0,msg:""}:Bt(F):{ok:!0,msg:""},[ee,N,F]),Pe=async()=>{if(ee&&N==="pattern"&&!B.ok){Y.error(B.msg);return}const r=j==="variation",g=j==="variation"?"range":j;await _({system:c,openaiModel:d,openai:m,grokKey:p,model:"openai",learnExamplesLimit:ge,triggerLearnExamplesLimit:xe,historyMaxLines:Number(me),msgLenMode:g,msgLenFixed:Number(K),msgLenFrom:Number(D),msgLenTo:Number(I),msgVarEnabled:!!r,msgVarStrategy:N,msgVarPattern:F,msgShortFrom:Number(P),msgShortTo:Number(V),msgLongFrom:Number(O),msgLongTo:Number(R)}),Y.success("Saved")},Ve=async r=>{const g=[...J];g.splice(r,1),await Vt("conversations",g),X(g),Y.success("Deleted")},Oe=async()=>{await Rt(),X([]),Y.success("Cleared")},Re=o.useMemo(()=>{if(j==="variation"){const ae=Math.min(P,V),Be=Math.max(P,V),He=Math.min(O,R),ze=Math.max(O,R);return`Variation: Short ${ae}–${Be} / Long ${He}–${ze} (${N==="pattern"?`Pattern ${F}`:"Random"})`}if(j==="fixed")return`Fixed: ${K} chars`;const r=Math.min(D,I),g=Math.max(D,I);return`${j==="random"?"Random pick from":"Range"}: ${r}–${g} chars`},[j,K,D,I,P,V,O,R,N,F]);return t.jsxs("div",{ref:se,className:"w-[780px] bg-gray-50 overflow-y-auto",children:[t.jsx(Dt,{position:"top-right"}),t.jsxs("div",{className:"sticky top-0 z-20 bg-gray-50 border-b border-gray-200",children:[t.jsxs("div",{className:"px-4 py-3 flex items-center justify-between",children:[t.jsx("div",{className:"text-base font-bold text-gray-900",children:"AI Chat Automation"}),t.jsxs("div",{className:"flex items-center gap-2",children:[!a&&e==="settings"&&t.jsx("button",{onClick:Pe,className:"px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700",children:"Save"}),t.jsx("button",{onClick:()=>i(r=>!r),className:"px-4 py-2 rounded-xl bg-white border border-gray-200 text-gray-700 text-sm font-semibold hover:bg-gray-50",children:a?"Back":"History"})]})]}),!a&&t.jsxs("div",{className:"px-4 pb-3 flex gap-2",children:[t.jsx(ne,{label:"Settings",active:e==="settings",onClick:()=>s("settings")}),t.jsx(ne,{label:"Stats",active:e==="stats",onClick:()=>s("stats")}),t.jsx(ne,{label:"Errors",active:e==="errors",onClick:()=>s("errors")})]})]}),t.jsx("div",{className:"p-4",children:a?t.jsx(L,{title:"Conversation History",children:t.jsxs("div",{className:"flex flex-col gap-3",children:[J.length===0?t.jsx("div",{className:"text-sm text-gray-500",children:"No saved conversations."}):J.map((r,g)=>t.jsxs("div",{className:"border border-gray-200 rounded-xl p-3 bg-white",children:[t.jsxs("div",{className:"text-sm",children:[t.jsx("span",{className:"font-semibold text-blue-600",children:"You:"})," ",r.You]}),t.jsxs("div",{className:"text-sm mt-1",children:[t.jsx("span",{className:"font-semibold text-purple-600",children:"Cust:"})," ",r.Customer]}),t.jsx("button",{onClick:()=>Ve(g),className:"mt-2 text-xs font-semibold text-red-600 hover:underline",children:"Delete"})]},g)),t.jsx("button",{onClick:Oe,className:"w-full mt-2 px-4 py-2 rounded-xl bg-red-100 text-red-700 font-semibold hover:bg-red-200",children:"Delete All"})]})}):e==="settings"?t.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-5 gap-4",children:[t.jsxs("div",{className:"lg:col-span-3 flex flex-col gap-4",children:[t.jsx(L,{title:"System Prompt",children:t.jsx("textarea",{ref:Ee,value:c,onChange:r=>{n(r.target.value),Me(r.target)},placeholder:"System prompt...",className:"w-full border border-gray-300 rounded-xl p-3 text-sm outline-none focus:ring-2 focus:ring-indigo-500 resize-none overflow-hidden",style:{minHeight:360}})}),t.jsx(L,{title:"Database",children:t.jsx("button",{onClick:()=>{typeof chrome<"u"&&chrome.tabs&&chrome.tabs.create({url:chrome.runtime.getURL("db-viewer.html")})},className:"w-full px-4 py-2.5 rounded-xl bg-indigo-700 text-white font-semibold hover:bg-indigo-800",children:"Open DB Viewer"})})]}),t.jsxs("div",{className:"lg:col-span-2 flex flex-col gap-4",children:[t.jsx(L,{title:"API Keys & Model",children:t.jsxs("div",{className:"flex flex-col gap-3",children:[t.jsxs("div",{children:[t.jsx(f,{children:"OpenAI API Key"}),t.jsx(oe,{type:"password",placeholder:"sk-...",value:m,onChange:r=>u(r.target.value)})]}),t.jsxs("div",{children:[t.jsx(f,{children:"Grok API Key"}),t.jsx(oe,{type:"password",placeholder:"xai-...",value:p,onChange:r=>h(r.target.value)})]}),t.jsxs("div",{children:[t.jsx(f,{children:"Model"}),t.jsxs($,{value:d,onChange:r=>l(r.target.value),children:[t.jsxs("optgroup",{label:"Grok (xAI)",children:[t.jsx("option",{value:"grok-4.20-reasoning",children:"grok-4.20-reasoning"}),t.jsx("option",{value:"grok-4.20",children:"grok-4.20"})]}),t.jsxs("optgroup",{label:"GPT-5",children:[t.jsx("option",{value:"gpt-5.4",children:"gpt-5.4"}),t.jsx("option",{value:"gpt-5.3-chat-latest",children:"gpt-5.3"}),t.jsx("option",{value:"gpt-5.2",children:"gpt-5.2"}),t.jsx("option",{value:"gpt-5.1",children:"gpt-5.1"}),t.jsx("option",{value:"gpt-5-mini",children:"gpt-5-mini"}),t.jsx("option",{value:"gpt-5-nano",children:"gpt-5-nano"})]}),t.jsx("optgroup",{label:"GPT 4",children:t.jsx("option",{value:"gpt-4.1",children:"gpt-4.1"})})]})]})]})}),t.jsx(L,{title:"Message Length",children:t.jsxs("div",{className:"flex flex-col gap-3",children:[t.jsxs("div",{children:[t.jsx(f,{children:"Mode"}),t.jsxs($,{value:j,onChange:r=>{const g=r.target.value;Ie(),Te(g),g==="variation"?(te(!0),Q("range")):(te(!1),Q(g))},children:[t.jsx("option",{value:"fixed",children:"Fixed"}),t.jsx("option",{value:"range",children:"Range"}),t.jsx("option",{value:"random",children:"Random"}),t.jsx("option",{value:"variation",children:"Variation (Short/Long)"})]}),t.jsxs("div",{className:"mt-2 text-xs font-semibold text-gray-500",children:["Preview:"," ",t.jsx("span",{className:"text-gray-800",children:Re})]})]}),j==="fixed"&&t.jsxs("div",{children:[t.jsx(f,{children:"Characters"}),t.jsx(T,{value:K,onValue:r=>fe(r),min:1,max:5e3,placeholder:"120"})]}),(j==="range"||j==="random")&&t.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[t.jsxs("div",{children:[t.jsx(f,{children:"From"}),t.jsx(T,{value:D,onValue:r=>ve(r),min:1,max:5e3,placeholder:"80"})]}),t.jsxs("div",{children:[t.jsx(f,{children:"To"}),t.jsx(T,{value:I,onValue:r=>be(r),min:1,max:5e3,placeholder:"150"})]})]}),j==="variation"&&t.jsxs("div",{className:"mt-2 flex flex-col gap-3",children:[t.jsxs("div",{children:[t.jsx(f,{children:"Strategy"}),t.jsxs($,{value:N,onChange:r=>ye(r.target.value),children:[t.jsx("option",{value:"pattern",children:"Pattern"}),t.jsx("option",{value:"random2",children:"Random"})]})]}),t.jsxs("div",{children:[t.jsx(f,{children:"Pattern"}),t.jsx(oe,{value:F,onChange:r=>je(r.target.value),disabled:N!=="pattern",placeholder:"2S1L",className:N==="pattern"&&!B.ok?"border-red-400 focus:ring-red-400":""}),N==="pattern"&&!B.ok&&t.jsx("div",{className:"mt-1 text-xs font-semibold text-red-600",children:B.msg})]}),t.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[t.jsxs("div",{children:[t.jsx(f,{children:"Short From"}),t.jsx(T,{value:P,onValue:r=>Ne(r),min:1,max:5e3,placeholder:"60"})]}),t.jsxs("div",{children:[t.jsx(f,{children:"Short To"}),t.jsx(T,{value:V,onValue:r=>Se(r),min:1,max:5e3,placeholder:"100"})]})]}),t.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[t.jsxs("div",{children:[t.jsx(f,{children:"Long From"}),t.jsx(T,{value:O,onValue:r=>Le(r),min:1,max:5e3,placeholder:"120"})]}),t.jsxs("div",{children:[t.jsx(f,{children:"Long To"}),t.jsx(T,{value:R,onValue:r=>we(r),min:1,max:5e3,placeholder:"180"})]})]})]})]})}),t.jsx(L,{title:"History lines sent to AI",children:t.jsxs("div",{className:"flex flex-col gap-2",children:[t.jsxs($,{value:me,onChange:r=>{const g=y(r.target.value,40,0,5e3);ue(g),_({historyMaxLines:g})},children:[t.jsx("option",{value:0,children:"All (old behavior)"}),t.jsx("option",{value:20,children:"20"}),t.jsx("option",{value:40,children:"40 (recommended)"}),t.jsx("option",{value:60,children:"60"}),t.jsx("option",{value:80,children:"80"})]}),t.jsx("p",{className:"text-xs text-gray-500",children:"All = old behavior. 40 is recommended for long chats. Personals still provide long-term facts."})]})}),t.jsx(L,{title:"Learn Examples",children:t.jsxs("div",{className:"flex flex-col gap-3",children:[t.jsxs("div",{children:[t.jsx(f,{children:"Normal Tags"}),t.jsx($,{value:ge,onChange:r=>{const g=y(r.target.value,30,1,500);pe(g),_({learnExamplesLimit:g})},children:[5,10,20,30,50].map(r=>t.jsx("option",{value:r,children:r},r))})]}),t.jsxs("div",{children:[t.jsx(f,{children:"Trigger Tags"}),t.jsx($,{value:xe,onChange:r=>{const g=y(r.target.value,2,1,100);he(g),_({triggerLearnExamplesLimit:g})},children:[2,5,10].map(r=>t.jsx("option",{value:r,children:r},r))})]})]})})]})]}):e==="stats"?t.jsx("div",{className:"flex flex-col gap-4",children:t.jsx(L,{title:"Stats",children:t.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[t.jsxs("div",{children:[t.jsx("div",{className:"text-xs text-gray-500",children:"Cost"}),t.jsxs("div",{className:"text-lg font-bold",children:["$",x?.cost||"0.000000"]})]}),t.jsxs("div",{children:[t.jsx("div",{className:"text-xs text-gray-500",children:"Model"}),t.jsx("div",{className:"text-lg font-bold",children:x?.model||"-"})]}),t.jsxs("div",{children:[t.jsx("div",{className:"text-xs text-gray-500",children:"Input Tokens"}),t.jsx("div",{className:"text-lg font-bold",children:x?.promptTokens||0})]}),t.jsxs("div",{children:[t.jsx("div",{className:"text-xs text-gray-500",children:"Output Tokens"}),t.jsx("div",{className:"text-lg font-bold",children:x?.completionTokens||0})]}),t.jsxs("div",{className:"col-span-2",children:[t.jsx("div",{className:"text-xs text-gray-500",children:"Total Tokens"}),t.jsx("div",{className:"text-lg font-bold",children:x?.totalTokens||0})]})]})})}):t.jsx("div",{className:"flex flex-col gap-4",children:t.jsx(L,{title:"Errors",children:E?t.jsxs("div",{className:"border border-red-200 bg-red-50 rounded-xl p-3",children:[t.jsxs("div",{className:"flex items-start justify-between gap-2",children:[t.jsxs("div",{children:[t.jsx("div",{className:"text-sm font-bold text-red-800",children:E.title}),t.jsx("div",{className:"text-xs text-red-500",children:new Date(E.timestamp).toLocaleString()})]}),t.jsx("button",{onClick:()=>de(null),className:"text-xs font-semibold text-red-700 hover:underline",children:"Clear"})]}),t.jsx("div",{className:"mt-2 text-xs font-mono text-red-800 bg-red-100 rounded-lg p-2 break-words",children:E.details})]}):t.jsx("div",{className:"text-sm text-gray-500",children:"No errors."})})})})]})}Ue.createRoot(document.getElementById("root")).render(t.jsx(o.StrictMode,{children:t.jsx(Ht,{})}));
