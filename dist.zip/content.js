(() => {
  // dist/chunks/promptPacking-D04x8Jew.js
  function L(e) {
    return typeof e == "string" && e.trim().startsWith("(trigger)");
  }
  function w(e) {
    return f(e) != null;
  }
  function f(e) {
    const t = String(e ?? "").toLowerCase();
    return t.trim() ? t.includes("leere nachricht") ? "(trigger) Leere Nachricht" : t.includes("please reactivate the user") ? "(trigger) Please reactivate the user!" : t.includes("[kiss]") ? "(trigger) [kiss]" : t.includes("[heart]") ? "(trigger) [heart]" : t.includes("[klaps]") || t.includes("[slap]") ? "(trigger) [Klaps]" : null : null;
  }

  // dist/content.js
  var J = /* @__PURE__ */ new Set(["agents.moderationinterface.com", "chat.freedomgpt.com"]);
  J.has(window.location.hostname);
  (function() {
    const e = "app-multiple-tabs-modal";
    console.log("\u{1F680} Auto-Disconnect service started...");
    const n = () => {
      const r = document.querySelector(e);
      if (!r) return;
      const i = Array.from(r.querySelectorAll("button")).find((s) => {
        const c = s.className.toLowerCase(), u = (s.textContent || "").toLowerCase(), l = c.includes("btn-danger"), m = u.includes("ok") || u.includes("disconnect");
        return !l && m;
      });
      if (i) {
        const s = i.getBoundingClientRect();
        if (s.width > 0 && s.height > 0) {
          console.log("\u2705 Found 'Disconnect' button. Clicking now..."), i.click();
          const c = new MouseEvent("click", { view: window, bubbles: true, cancelable: true });
          i.dispatchEvent(c);
        }
      }
    };
    new MutationObserver((r) => {
      for (const a of r) a.addedNodes.length && document.querySelector(e) && n();
    }).observe(document.body, { childList: true, subtree: true }), setInterval(n, 1e3), document.addEventListener("visibilitychange", () => {
      document.hidden || n();
    });
  })();
  var D = ["flirty", "soft", "question", "Erotic", "flirty and soft", "flirty and question", "flirty and erotic", "soft and question", "Soft and erotic", "Question and erotic", "(trigger) Leere Nachricht", "(trigger) [kiss]", "(trigger) [heart]", "(trigger) [Klaps]", "(trigger) Please reactivate the user!"];
  var j = D[0];
  var w2 = { textBox: "chat-windows-message-textarea" };
  var v = { mainCard: "card-body", userMessage: "li.ng-star-inserted .timeline-body", agentMessage: "li.timeline-inverted.ng-star-inserted .timeline-body", loading: ".loading-text" };
  var f2 = 2;
  var O = false;
  var A = false;
  function z(t) {
    const e = (typeof t == "string" ? t : "").trim();
    if (!e) return false;
    const n = ["Name:", "Age:", "City:", "Job:", "Sex preference:", "Others:"], o = e.toLowerCase();
    return n.every((a) => o.includes(a.toLowerCase())) ? true : e.split(`
`).some((a) => {
      const i = a.indexOf(":");
      return i === -1 ? false : a.slice(i + 1).trim().length > 0;
    });
  }
  function T() {
    try {
      return !!(typeof chrome < "u" && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }
  function M(t) {
    if (T()) try {
      chrome.runtime.sendMessage(t, () => {
        chrome.runtime?.lastError;
      });
    } catch {
    }
  }
  function G(t, e) {
    t && (t.value = e, t.dispatchEvent(new Event("input", { bubbles: true })), t.dispatchEvent(new Event("change", { bubbles: true })));
  }
  chrome.runtime.onMessage.addListener(async (t) => {
    if (T()) try {
      if (t.type === "suggestionResponse" && f2 === 2) {
        p();
        const n = document.getElementById(w2.textBox)?.closest("." + v.mainCard);
        if (!n) return;
        let o = document.getElementById("ai-suggestion-card"), r = "";
        if (t?.payload?.success && (r = (t.payload?.message || "").trim()), !o) {
          o = document.createElement("div"), o.id = "ai-suggestion-card", o.style.cssText = `
          width: 100%;
          background: #f5f5f5;
          border: 1px solid #ccc;
          border-radius: 6px;
          padding: 2px;
          font-family: monospace;
          font-size: 14px;
          display: flex;
          flex-direction: column;
          overflow-y: auto;
          max-height: 140px;
          box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        `;
          const a = document.getElementById("mode-switcher");
          a ? n.insertBefore(o, a) : n.appendChild(o);
        }
        if (!t?.payload?.success) o.textContent = t?.payload?.error || "\u274C Failed to get suggestion from AI.", o.style.color = "red";
        else {
          await I("lastAISuggestion", r, 10);
          let a = await h("suggestions") || [];
          a.includes(r) || (a.length >= 10 && a.shift(), a.push(r)), o.innerHTML = `
          <b>\u{1F4AC}Suggested reply:</b>
          <p>${ne(r)}</p>
          <div style="display:flex;justify-content:center;gap:5px;flex-wrap:wrap;">
            <button id="insert-suggestion-btn" style="
              width: 120px;height: 32px;padding: 2px 8px;font-size: 13px;
              background-color: #4CAF50;color: white;border: none;border-radius: 6px;cursor: pointer;">
              Insert Text
            </button>
            <button id="insert-send-suggestion-btn" style="
              width: 120px;height: 32px;padding: 2px 8px;font-size: 13px;
              background-color: #2196F3;color: white;border: none;border-radius: 6px;cursor: pointer;">
              Insert & Send
            </button>
          </div>
        `, document.getElementById("insert-suggestion-btn")?.addEventListener("click", () => K(r)), document.getElementById("insert-send-suggestion-btn")?.addEventListener("click", () => Q(r));
        }
      }
      if (t.type === "autoResponse" && f2 === 3) {
        if (p(), !t?.payload?.success) {
          y(t?.payload?.error || "\u274C Failed to get suggestion from AI."), p();
          return;
        }
        const e = (t?.payload?.message || "").trim();
        if (!e) return console.warn("\u26A0\uFE0F Empty AI response payload.");
        await I("lastAISuggestion", e, 10);
        const n = document.getElementById(w2.textBox);
        if (!n) return console.error("\u274C Textbox not found.");
        if (e.length < 70 && !await H()) {
          y("\u26A0\uFE0F Response too short Regenerating..."), await new Promise((r) => setTimeout(r, 2e3)), p(), await F();
          return;
        }
        let o = document.querySelector('button[type="submit"]');
        if (!o) return console.error("\u274C Send button not found.");
        n.focus(), document.execCommand("insertText", false, e), n.value = e, n.dispatchEvent(new Event("input", { bubbles: true })), n.dispatchEvent(new Event("change", { bubbles: true })), n.focus(), o?.removeAttribute("disabled");
        for (let r = 0; r < 10; r++) y("Waiting time: " + (10 - r) + " seconds..."), await new Promise((a) => setTimeout(a, 1e3)), p();
        o.click(), await new Promise((r) => setTimeout(r, 1e3));
      }
      if (t.type === "personalsResponse") {
        const e = t?.payload || {};
        if (!e.success) {
          console.warn("\u274C personalsResponse failed:", e.error);
          return;
        }
        const n = document.getElementById("customer-custom"), o = document.getElementById("moderator-custom"), r = typeof e.customerPersonal == "string" ? e.customerPersonal.trim() : "", a = typeof e.moderatorPersonal == "string" ? e.moderatorPersonal.trim() : "";
        n && z(r) && G(n, r), o && z(a) && G(o, a);
        const i = n?.value?.trim() || "", s = o?.value?.trim() || "";
        if (await d("customerPersonal", i), await d("moderatorPersonal", s), await d("personals", `You: ${s}, customer${i}`), typeof e.tag == "string" && e.tag.trim()) {
          const c = e.tag.trim();
          await d("selectedTag", c);
          const u = document.getElementById("learn-tag-select");
          u && (u.value = c);
        }
      }
    } catch {
    }
  });
  async function K(t) {
    if (O = true, t.length < 75 && !await H()) {
      y("\u26A0\uFE0F Response too short Regenerating..."), await new Promise((n) => setTimeout(n, 2e3)), p(), await L2();
      return;
    }
    const e = document.getElementById(w2.textBox);
    e && (e.focus(), e.value = t, await new Promise((n) => setTimeout(n, 1e3)), _());
  }
  async function Q(t) {
    O = true;
    let e = document.querySelector('button[type="submit"]');
    if (t.length < 75 && !await H()) {
      y("\u26A0\uFE0F Response too short Regenerating..."), await new Promise((o) => setTimeout(o, 2e3)), p(), await L2();
      return;
    }
    const n = document.getElementById(w2.textBox);
    n && (n.focus(), document.execCommand("insertText", false, t), n.dispatchEvent(new Event("input", { bubbles: true })), n.dispatchEvent(new Event("change", { bubbles: true })), n.focus(), n.value = t, e?.removeAttribute("disabled"), await $(t), await new Promise((o) => setTimeout(o, 1e3)), _());
  }
  function y(t = "Working...") {
    p();
    const e = document.createElement("div");
    e.id = "process-banner", e.textContent = t, e.style.cssText = `
    position: fixed; top: 10px; left: 50%;
    transform: translateX(-50%);
    background-color: #007bff; color: white;
    padding: 8px 16px; border-radius: 5px;
    font-weight: bold; z-index: 9999;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  `, document.body.appendChild(e);
  }
  function p() {
    const t = document.getElementById("process-banner");
    t && t.remove();
  }
  function S() {
    return document.getElementById(w2.textBox) || document.querySelector("textarea#chat-windows-message-textarea");
  }
  function X(t) {
    return t ? t.closest("." + v.mainCard) || t.closest(".card") || t.closest("form") || t.parentElement : null;
  }
  async function Y(t) {
    const e = X(t);
    if (!e) return false;
    if (te(), !document.getElementById("mode-switcher")) {
      const n = document.createElement("div");
      n.id = "mode-switcher", n.style.marginTop = "10px", n.style.display = "flex", n.style.alignItems = "center", n.style.gap = "6px", n.style.flexWrap = "wrap";
      const o = document.createElement("button");
      o.id = "mode-learn", o.textContent = "Learn", o.className = "mode-btn active";
      const r = document.createElement("select");
      r.id = "learn-tag-select", r.className = "tag-select", D.forEach((l) => {
        const m = document.createElement("option");
        m.value = l, m.textContent = l, r.appendChild(m);
      });
      const a = await C("selectedTag"), i = D.includes(a) ? a : j;
      r.value = i, await d("selectedTag", i), r.addEventListener("change", async (l) => {
        await d("selectedTag", l.target.value);
      });
      const s = document.createElement("button");
      s.id = "mode-suggest", s.textContent = "Suggest", s.className = "mode-btn";
      const c = document.createElement("button");
      c.id = "mode-auto", c.textContent = "Auto", c.className = "mode-btn", n.appendChild(o), n.appendChild(r), n.appendChild(s), n.appendChild(c), e.appendChild(n), f2 === 2 && s.classList.add("active"), f2 === 3 && c.classList.add("active");
      const u = { 2: s, 3: c };
      Object.entries(u).forEach(([l, m]) => {
        m.addEventListener("click", () => {
          Object.values(u).forEach((k) => k.classList.remove("active")), m.classList.add("active"), f2 = parseInt(l), f2 === 2 && L2(), f2 === 3 && F();
        });
      }), o.addEventListener("click", () => Z());
    }
    return document.getElementById("manual-suggestion-wrapper") || ee(e), true;
  }
  var R = false;
  async function P() {
    if (!R) {
      R = true, A = false;
      try {
        let t;
        for (; !t; ) t = S(), await new Promise((e) => setTimeout(e, 500));
        for (; t?.disabled; ) await new Promise((e) => setTimeout(e, 500)), t = S();
        O = false, await Y(t), y("Collecting messages, please wait...");
        try {
          await N(30);
        } catch (e) {
          console.error("\u274C grabData failed (overlay still shown):", e);
        }
        p(), await new Promise((e) => setTimeout(e, 1200)), document.getElementById("mode-switcher") || await Y(S()), f2 === 2 ? L2() : f2 === 3 && F();
      } finally {
        R = false;
      }
    }
  }
  async function F() {
    y("AI is auto-filling, please wait..."), A === false && await N(10), M({ type: "autoFill" });
  }
  async function L2() {
    y("Please wait, getting suggestion..."), A === false && await N(10), M({ type: "getSuggestion" });
  }
  async function Z() {
    await $();
    const t = document.getElementById(w2.textBox);
    if (!t) return;
    const e = t.value.trim();
    if (!(!e || e.length < 3)) try {
      const n = document.getElementById("learn-tag-select")?.value || await C("selectedTag") || j, o = await h("training"), r = (Array.isArray(o) ? o : []).map((s) => {
        if (typeof s == "string") return { message: s, tag: n };
        if (s && typeof s == "object") {
          const c = s.message ?? s.messages, u = s.tag ?? n;
          return typeof c != "string" || !c.trim() ? null : { message: c, tag: u };
        }
        return null;
      }).filter(Boolean);
      if (r.some((s) => s.message === e && String(s.tag) === String(n))) return;
      const i = r.concat([{ message: e, tag: n }]);
      for (; i.length > 1e3; ) i.shift();
      B("training", i), _();
    } catch (n) {
      console.error("\u274C Failed to update messages:", n);
    }
  }
  async function $(t = null) {
    let e = "";
    if (t) e = t;
    else {
      const r = document.getElementById(w2.textBox);
      if (!r || (e = r.value.trim(), !e || e.length < 3)) return;
    }
    const o = (await h("currentMessage"))?.[0]?.content?.trim();
    if (o) try {
      M({ type: "storeConversations", data: { You: e, Customer: o, date: (/* @__PURE__ */ new Date()).toISOString() } });
    } catch (r) {
      console.error("\u274C Failed to save to IDB:", r);
    }
  }
  async function N(t = 4) {
    let e = 0;
    for (let g = 0; g < t; g++) {
      const x = document.body.scrollHeight;
      if (x === e && g <= 2) break;
      e = x, window.scrollTo({ top: x, behavior: "smooth" });
      let b = 0;
      for (; document.querySelector(".alert.alert-info.text-center") && b < 5e3; ) await new Promise((q) => setTimeout(q, 200)), b += 500;
      await new Promise((q) => setTimeout(q, 1e3));
    }
    window.scrollTo({ top: 0 });
    let n = [], o = [];
    const r = document.querySelectorAll("li.ng-star-inserted .timeline-heading"), a = r.length > 0 ? (r[r.length - 1]?.innerText || "").trim() : "";
    await d("latestMessageDate", a), await d("botNow", (/* @__PURE__ */ new Date()).toString()), document.querySelectorAll("li.ng-star-inserted").forEach((g) => {
      const x = g.querySelector(".timeline-body");
      if (!x) return;
      const b = x.innerText?.trim();
      b && (g.classList.contains("timeline-inverted") ? n.push(`You: ${b}`) : n.push(`Customer: ${b}`));
    });
    let s = "";
    const c = n.slice().reverse().find((g) => /^Customer:\s*/i.test(g));
    if (c) s = c.replace(/^Customer:\s*/i, "").trim();
    else {
      const g = document.querySelectorAll("li.ng-star-inserted:not(.timeline-inverted) .timeline-body");
      g.length > 0 && (s = g[g.length - 1]?.innerText?.trim() || "");
    }
    o.push({ role: "user", content: s || "" });
    const u = n.slice(), l = document.getElementById("customer-custom")?.value || "", m = document.getElementById("moderator-custom")?.value || "", k = document.querySelector(".badge.badge-primary.float-right.ng-star-inserted")?.innerText || "";
    await d("customerPersonal", l.trim()), await d("moderatorPersonal", m.trim()), await d("conversationStart", k.trim()), await d("personals", `You: ${m.trim()}, customer${l.trim()}`), await M({ type: "processPersonals", data: { customerPersonal: l, moderatorPersonal: m }, conversationHistory: u }), B("messages", n), B("currentMessage", o), A = true;
  }
  function B(t, e) {
    if (!(!T() || !Array.isArray(e))) try {
      chrome.storage.local.set({ [t]: e }, () => {
        chrome.runtime?.lastError;
      });
    } catch {
    }
  }
  function h(t) {
    return new Promise((e) => {
      if (!T()) return e([]);
      try {
        chrome.storage.local.get([t], (n) => {
          if (chrome.runtime?.lastError) return e([]);
          const o = n?.[t];
          e(Array.isArray(o) ? o : []);
        });
      } catch {
        e([]);
      }
    });
  }
  function C(t) {
    return new Promise((e) => {
      if (!T()) return e(void 0);
      try {
        chrome.storage.local.get([t], (n) => {
          if (chrome.runtime?.lastError) return e(void 0);
          e(n?.[t]);
        });
      } catch {
        e(void 0);
      }
    });
  }
  async function H() {
    try {
      const t = await C("selectedTag");
      if (L(t)) return true;
      const n = (await h("currentMessage"))?.[0]?.content || "";
      return w(n);
    } catch {
      return false;
    }
  }
  function d(t, e) {
    return new Promise((n) => {
      if (!T()) return n(false);
      try {
        chrome.storage.local.set({ [t]: e }, () => {
          if (chrome.runtime?.lastError) return n(false);
          n(true);
        });
      } catch {
        n(false);
      }
    });
  }
  async function I(t, e, n = 120) {
    let o = await h(t);
    if (Array.isArray(o) || (o = []), o.includes(e)) return o.length;
    for (; o.length >= n; ) o.shift();
    return o.push(e), B(t, o), o.length;
  }
  var U = () => {
    const t = document.querySelector('button[type="submit"]');
    if (!t) {
      setTimeout(U, 500);
      return;
    }
    t.addEventListener("click", async () => {
      await $();
      let e = document.querySelector(v.loading), n = 0;
      for (; !e && n < 10; ) e = document.querySelector(v.loading), await new Promise((o) => setTimeout(o, 500)), n++;
      e && (E("ai-suggestion-card"), E("mode-switcher"), E("manual-suggestion-wrapper"), B("suggestions", []), await new Promise((o) => setTimeout(o, 3e3)), P());
    });
  };
  async function _() {
    let t = document.querySelector(v.loading), e = 0;
    for (; !t && e < 10; ) t = document.querySelector(v.loading), await new Promise((n) => setTimeout(n, 500)), e++;
    t && (E("ai-suggestion-card"), E("mode-switcher"), E("manual-suggestion-wrapper"), await new Promise((n) => setTimeout(n, 1e3)), B("suggestions", []), P());
  }
  function ee(t) {
    const e = document.createElement("div");
    e.id = "manual-suggestion-wrapper", e.style.cssText = "display:flex;align-items:center;gap:8px;margin-top:8px;flex-wrap:wrap;";
    const n = document.createElement("input");
    n.id = "manual-suggestion-input", n.type = "text", n.placeholder = "Type a suggested message\u2026", n.style.cssText = "flex:1;min-width:220px;padding:8px 10px;border:1px solid #ccc;border-radius:6px;", C("suggestion").then((i) => {
      typeof i == "string" && (n.value = i);
    }), n.addEventListener("input", async (i) => {
      await d("suggestion", i.target.value ?? "");
    });
    const o = document.createElement("button");
    o.textContent = "+ Add", o.style.cssText = "padding:8px 12px;background:#6c5ce7;color:#fff;border:none;border-radius:6px;cursor:pointer;", o.addEventListener("click", async () => {
      const i = n.value?.trim();
      if (!i) return;
      const c = (await h("currentMessage"))?.[0]?.content?.trim() || "";
      if (!c) return;
      const u = `You: ${i}, Customer: ${c}`;
      await I("suggestions", u, 10);
    });
    const r = document.createElement("button");
    r.textContent = "\u{1F6A9} Report Bad suggestion", r.style.cssText = "padding:8px 12px;background:#e74c3c;color:#fff;border:none;border-radius:6px;cursor:pointer;", r.addEventListener("click", async () => {
      const i = (await C("lastAISuggestion"))?.[0] || "", c = (await h("currentMessage"))?.[0]?.content?.trim() || "", u = document?.getElementById(w2.textBox);
      if (!u || !u?.value) return;
      const l = `Customer Message: ${c}
 Bad Response:${i},Good Response:${u.value} `;
      await I("badResponses", l, 10);
    }), e.appendChild(n), e.appendChild(o), e.appendChild(r);
    const a = document.getElementById("mode-switcher");
    a?.parentElement ? a.parentElement.insertBefore(e, a.nextSibling) : t.appendChild(e);
  }
  function te() {
    if (document.getElementById("mode-style-tag")) return;
    const t = document.createElement("style");
    t.id = "mode-style-tag", t.textContent = `
    .mode-btn { margin-right: 5px; color: white; border: none; padding: 5px 10px;
      border-radius: 4px; opacity: 0.6; cursor: pointer; }
    .mode-btn.active { opacity: 1; box-shadow: 0 0 6px rgba(0,0,0,0.4); }
    #mode-suggest, #mode-auto { background: #000; }
    #mode-learn { background: #6cf542; }
    .tag-select { height: 28px; border: 1px solid #ccc; border-radius: 6px;
      padding: 0 8px; font-size: 12px; background: #fff; }
  `, document.head.appendChild(t);
  }
  function E(t) {
    const e = document.getElementById(t);
    e && e.remove();
  }
  function ne(t) {
    return (t || "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
  }
  function oe() {
    const t = () => {
      document.getElementById("mode-switcher") || S() && P();
    };
    document.body && new MutationObserver(t).observe(document.body, { childList: true, subtree: true });
  }
  U();
  oe();
  P();
})();
